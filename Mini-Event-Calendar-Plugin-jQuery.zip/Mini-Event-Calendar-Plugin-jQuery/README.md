# jquery-mini-event-calendar
Jquery mini event calendar.

## how to use
Download and include `mini-event-calendar.min.js` and `mini-event-calendar.min.css` then include them in your site.

Check out `exmple.html` to see how to use.